<?php 
/**
 * AQ_Config class
 *
 * This hold the configurations and settings for the
 * Aqua Page Builder plugin.
 * 
 * Contains filter for theme authors to define
 * their own custom configurations
 */
 class AQ_Config() {
 	
 	public $config = array();
 	
 	function __construct() {
 		
 	}
 	
 }