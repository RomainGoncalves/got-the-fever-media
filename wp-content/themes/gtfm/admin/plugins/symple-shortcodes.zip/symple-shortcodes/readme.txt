=== Symple Shortcodes ===

Author URI: http://www.wpexplorer.com | http://themeforest.net/user/WPExplorer?ref=wpexplorer
Plugin URI: http://www.wpexplorer.com/symple-shortcodes
Author: AJ Clarke
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin was created to make it easier for you to use shortcodes on your WordPress sites.
Many themes out there already have shortcodes built-in, but if you ever switch themes you'll lose your shortcodes unless you know how to transfer over the functions and the styling.
Symple Shortcodes will go with you everywhere you need them.
Enjoy!
